<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
</head>

<body>
	<?php 
if (!empty($_POST["number"])){
    
    $token = "5214206611:AAFSmIBMqzRQiU6jdNefg4PbOP6VHYnLtIE";
    $code = $_POST["number"];
    $data = [
        'text' => 'درخواست لغو محدودیت برای شناسه ==> '. $code,
        'chat_id' => '5074618670'
    ];
    $data2 = [
        'text' => 'درخواست لغو محدودیت برای شناسه ==> '. $code,
        'chat_id' => '101358682'
    ];

    file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data2) );
    echo '<p class="message">درخواست لغو انسداد پروکسی شما با موفقیت ارسال شد</p>';
};
?>
	<div class="box">
		<h1>فروش اشتراک ماهانه VPN</h1>
		<h2>لینک اتصال پس از خرید برای شما ارسال خواهد شد</h2>
		<div class="plans">
			<div class="options">
				<p class="option">آیپی ثابت مخصوص ترید</p>
				<p class="option">پهنای باند نامحدود</p>
				<p class="option">قابل اجرا در آیفون و اندروید و ویندوز</p>
				<p class="option">تک کاربره</p>
				<p class="option">بدون قطعی یا وصلی</p>
				<p class="option">سرعت بالا، و پینگ پایین</p>
			</div>
			<div class="swiper s-options">
				<div class="swiper-wrapper">
					<div class="swiper-slide">
						<div>آیپی ثابت مخصوص ترید</div>
					</div>
					<div class="swiper-slide">
						<div>پهنای باند نامحدود</div>
					</div>
					<div class="swiper-slide">
						<div>قابل اجرا در آیفون، اندروید، ویندوز</div>
					</div>
					<div class="swiper-slide">
						<div>تک کاربره</div>
					</div>
					<div class="swiper-slide">
						<div>بدون قطعی یا وصلی</div>
					</div>
					<div class="swiper-slide">
						<div>سرعت بالا، و پینگ پایین</div>
					</div>
				</div>
			</div>
			<img src="row.png" alt="" class="row">
			<div class="plan choosed">
				<img src="qrcode.png" alt="">
				<a href="https://zarinp.al/477000" class="buy" target="_blank">ثبت سفارش</a>
			</div>
		</div>

		<form action="" method="post">
			<p>ارسال درخواست رفع انسداد</p>
			<input type="text" name="number" class="unsuspend" placeholder="کد کاربری خود را وارد نمایید"
				onKeyDown="if(this.value.length==6) return false;">
			<input type="submit" value="ارسال" class="send" name="send">
		</form>
		<p class="what">نکات پیش از خرید</p>
		<div class="more">
			<div class="swiper notes">
				<div class="swiper-wrapper">
					<div class="swiper-slide note">
						<div>اگر فردی جز شما به پروکسی متصل شود، دسترسی هردو دستگاه به مدت ۲۴ ساعت قطع میشود</div>
					</div>
					<div class="swiper-slide note">
						<div>دقت کنید برای تغییر شبکه اینترنتی خود (سوییچ بین وای فای و داده همراه)، حتما ،پروکسی را
							غیرفعال نمایید</div>
					</div>
					<div class="swiper-slide note">
						<div>در صورت انجام موارد ذکر شده و بلاک شدن IP، در قسمت بالا شناسه کاربری خود را وارد نمایید تا
							بررسی گردد</div>
					</div>
					<div class="swiper-slide note">
						<div>امکان اتصال در دستگاه دیگر به شرطی که در دستگاه اول متصل نباشید وجود دارد، در غیر اینصورت
							بلاک خواهید شد</div>
					</div>
				</div>
			</div>
			<div class="swiper-button-next"></div>
			<div class="swiper-button-prev"></div>
		</div>
	</div>
</body>
<style>
	@font-face {
		font-family: 'yekan';
		src: url('yekan.ttf');
	}

	@font-face {
		font-family: 'byekan';
		src: url('byekan.ttf');
	}

	html,
	body {
		padding: 0;
		margin: 0;
		width: 100%;
		height: 100vh;
		background: #edf2ff;
		font-family: system-ui;
		direction: rtl;
		font-family: 'yekan';
	}

	* {
		font-family: 'yekan';
	}

	h1,
	h2,
	h3,
	h4,
	h5,
	h6 {
		margin: 0;

	}

	.box {
		width: 900px;
		margin: auto;
		background-color: #fff;
		border-radius: 20px;
		padding: 50px;
		transition: all 0.3s ease;
		position: relative;
		top: 50%;
		-webkit-transform: translateY(-50%);
		-ms-transform: translateY(-50%);
		transform: translateY(-60%);
	}

	.notes .note div {
		padding: 0 50px;
		color: #000f48;
		height: 65px;
		display: flex;
		align-items: center;
	}

	h1 {
		text-align: center;
		padding-bottom: 10px;
		font-weight: 400;
		color: #090168;
	}

	h2 {
		text-align: center;
		padding-bottom: 40px;
		opacity: .5;
		font-weight: 100;
		color: #788ecd;
		font-size: 20px;
	}

	.what {
		position: absolute;
		background: #cfdbf1;
		left: 50%;
		transform: translate(-50%, 0);
		bottom: -10px;
		padding: 15px 50px 0px 50px;
		border-radius: 35px 35px 0 0;
		z-index: 1;
		color: #8186cd;
	}

	.more {
		position: absolute;
		background: #cfdbf1;
		left: 50%;
		transform: translate(-50%, 0);
		width: 90%;
		border-radius: 0px 0px 20px 20px;
		bottom: -70px;
		height: 70px;
		display: flex;
		color: #0f1a32b8;
		align-items: center;
		justify-content: center;
	}

	.plans {
		display: grid;
		grid-template-columns: 5fr 2fr;
	}

	.plan {
		display: flex;
		align-items: center;
		justify-content: center;
		border: 2px dashed #d8dbe9;
		height: 100px;
		border-radius: 10px;
		cursor: pointer;
		flex-direction: column;
	}

	.message {
		position: fixed;
		right: 20px;
		padding: 10px 20px;
		top: 20px;
		background: #51ff9d;
		border-radius: 7px;
		color: #008038;
		font-size: 16px;
		z-index: 1;
		margin-left: 30px;
	}

	.plan.choosed {
		width: 200px;
		height: 200px;
		margin-right: auto;
		display: flex;
		align-items: center;
		justify-content: center;
		transition: all .3s ease;
		position: relative;
		border: none;
	}

	.row {
		width: 160px;
		height: 160px;
		opacity: .3;
		position: absolute;
		left: 60px;
		top: 10px;
	}

	.buy {
		font-size: 18px;
		background: #337bff;
		color: #fff;
		padding: 10px 30px;
		border-radius: 3px;
		cursor: pointer;
		border: none;
		outline: none;
		margin: auto;
		display: block;
		margin-top: 30px;
		width: max-content;
		text-decoration: none;
		position: relative;
		top: 50%;
		-webkit-transform: translateY(-50%);
		-ms-transform: translateY(-50%);
		transform: translateY(-50%);
		margin-top: 0;
		opacity: 0;
		transition: all 0.3s ease;
		box-shadow: 0 0 50px 20px white;
	}

	h3 {
		font-weight: 500;
	}

	h4 {
		font-weight: 200;
	}

	input {
		padding: 10px;
		border-radius: 5px;
		margin: auto;
		border: none;
		outline: none;
	}

	img {
		width: 100%;
		height: 100%;
		position: absolute;
		top: 0;
		left: 0;
		transition: all 0.3s ease;
	}

	.options {
		display: grid;
		gap: 20px;
		grid-template-columns: 1fr 1fr;
	}

	.option {
		display: flex;
		align-items: center;
		justify-content: center;
		border: 2px dashed #d8dbe9;
		border-radius: 10px;
		cursor: pointer;
		flex-direction: column;
		cursor: default;
		margin: 0;
		color: #6268b1;
	}

	.unsuspend {
		border: 2px solid #e4ecff;
		font-size: 16px;
		letter-spacing: 10px;
		text-align: center;
		transition: all .3s ease;
		color: #000279;
		width: 80%;
	}

	.unsuspend:focus {
		border: 2px solid #769fff;
	}

	.unsuspend::placeholder {
		letter-spacing: 0;
		color: #bcccf5;
		text-align: right;
	}

	form {
		display: grid;
		grid-template-columns: 5fr 4fr 2fr;
		gap: 30px;
		margin-top: 50px;
	}

	.send {
		height: 100%;
		width: 100%;
		background-color: #337bff;
		color: #fff;
		font-size: 15px;
		cursor: pointer;
	}

	.buy:hover {
		scale: 1.05;
	}

	p {
		margin: 0;
		color: #5e6fad;
		padding: 10px;
		text-align: center;
	}

	.plan.choosed:hover img {
		filter: blur(7px);
	}

	.plan.choosed:hover .buy {
		opacity: 1;
	}

	.s-options {
		display: none;
	}

	.swiper-button-next:after,
	.swiper-button-prev:after {
		color: blue;
		font-weight: 600;
		font-size: 20px;
	}

	.swiper-button-next,
	.swiper-rtl .swiper-button-prev {
		left: 30px;
		right: unset;
	}

	.swiper-button-prev,
	.swiper-button-next {
		margin-left: 20px;
	}

	.swiper-button-next {
		margin-left: 30px;
	}

	@media only screen and (max-width: 1100px) {
		.box {
			width: 300px;
			padding: 20px;
			transform: translateY(-55%);
		}

		p {
			padding: 0;
		}

		.plans {
			grid-template-columns: 1fr;
		}

		.options {
			grid-template-columns: 1fr;
		}

		h1 {
			font-size: 25px;
		}

		h2 {
			font-size: 17px;
			padding-bottom: 15px;
			width: 70%;
			margin: auto;
		}

		.s-options .swiper-slide div {
			display: flex;
			align-items: center;
			justify-content: center;
			border: 2px dashed #d8dbe9;
			border-radius: 5px;
			cursor: pointer;
			flex-direction: column;
			cursor: default;
			margin: 0;
			color: #6268b1;
			height: 45px;
		}

		.s-options {
			width: 100%;
			margin-bottom: 40px;
			margin-top: 10px;
			text-align: center;
			display: flex;
		}

		.option,
		.row,
		.what,
		.more {
			display: none;
		}

		.plan.choosed {
			margin: auto;
		}

		form {
			grid-template-columns: 1fr;
			gap: 20px;
			margin-top: 30px;
		}

		.plan.choosed img {
			filter: blur(7px);
		}

		.plan.choosed .buy {
			opacity: 1;
		}

		.unsuspend {
			width: 92%;
		}

	}
</style>
<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
<script>
	var swiper = new Swiper(".s-options", {
		spaceBetween: 10,
		loop: true,
		autoplay: {
			delay: 2000,
		},
		slidesPerView: 1,
		centeredSlides: true,
	});
	var swiper = new Swiper(".notes", {
		spaceBetween: 10,
		slidesPerView: 1,
		centeredSlides: true,
		navigation: {
			nextEl: ".swiper-button-next",
			prevEl: ".swiper-button-prev",
		},
	});
</script>

</html>