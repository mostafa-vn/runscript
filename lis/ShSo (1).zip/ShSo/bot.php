<?php
/* * * * * * * * * * * 
In The Name of God 
Source Of Shahre Source
By PHP And Mysql
V.2.1
* * * * * * * * * *
Developer : MohammadReza Jafari
Telegram : @MohammadRezajiji
Phone : 09392287037
* * * * * * * * * * */
include 'config.php';
//========================== // jijibot // ==============================
function jijibot($method,$datas=[]){
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,'https://api.telegram.org/bot'.API_KEY.'/'.$method );
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    return json_decode(curl_exec($ch));
    }
//========================== // update // ==============================
$update = json_decode(file_get_contents('php://input'));
if(isset($update)){
    $telegram_ip_ranges = [
    ['lower' => '149.154.160.0', 'upper' => '149.154.175.255'],
    ['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],
    ];
    $ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR'])); $ok = false;
    foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
    $lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
    $upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
    if ($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok = true;
}
    if (!$ok) die();
}
if(isset($update->message)){
$message = $update->message;
$message_id = $message->message_id;
$text = convert($message->text);
$chat_id = $message->chat->id;
$tc = $message->chat->type;
$first_name = $message->from->first_name;
$from_id = $message->from->id;
// databse
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$from_id' LIMIT 1"));
$block = mysqli_query($connect,"SELECT * FROM `block` WHERE `id` = '$from_id' LIMIT 1");
}
if(isset($update->callback_query)){
$callback_query = $update->callback_query;
$callback_query_id = $callback_query->id;
$data = $callback_query->data;
$fromid = $callback_query->from->id;
$messageid = $callback_query->message->message_id;
$chatid = $callback_query->message->chat->id;
// databse
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$fromid' LIMIT 1"));
$block = mysqli_query($connect,"SELECT * FROM `block` WHERE `id` = '$fromid' LIMIT 1");
}
//==============================// function //=======================================
function convert($string) {
    $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $arabic = ['٩', '٨', '٧', '٦', '٥', '٤', '٣', '٢', '١','٠'];
    $num = range(0, 9);
    $convertedPersianNums = str_replace($persian, $num, $string);
    $englishNumbersOnly = str_replace($arabic, $num, $convertedPersianNums);
    return $englishNumbersOnly;
}
//==============================// keybord and Text //=======================================
$home = json_encode([
        'keyboard'=>[
		[['text'=>'🔍 جست و جو سورس']],
		[['text'=>'📊 جدیدترین ها'],['text'=>'❤️ محبوب ترین ها']],
		[['text'=>'➕ افزایش سکه'],['text'=>'👤 حساب کاربری']],
		[['text'=>'☎️ پشتیبانی'],['text'=>'ℹ️ راهنما']],
		],
          'resize_keyboard'=>true,
       		]);
$back = json_encode([
        'keyboard'=>[
		[['text'=>'🔙 بازگشت']],
		],
         'resize_keyboard'=>true,
       		]);	
$maintext = "✅ ربات $botname جهت دریافت سورس های داخل کانال $channelname و همچنین پشتیبانی کاربران ایجاد شده است

☑️ اگر سورس را نمیتوانید دریافت کنید یا از دست داده اید میتوانید از بخش افزایش سکه استفاده کنید .
👇🏻 از منوی پایین انتخاب کنید";		
//===========================// block //===========================
if (mysqli_num_rows($block) > 0) exit();
//===========================// start //===========================
elseif(preg_match('/^(\/start) file_(.*)/', $text , $match)){
	if(jijibot('getChatMember',['chat_id'=>"@$channel",'user_id'=>$from_id])->result->status != 'left'){
	$file = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `file` WHERE `id` = '$match[2]' LIMIT 1"));
	if(mysqli_num_rows(mysqli_query($connect,"SELECT * FROM `download` WHERE `file` = '$match[2]' AND `id` = '$from_id' LIMIT 1")) > 0)
	jijibot('sendDocument',[
	'chat_id'=>$from_id,
	'document'=>$file['file'],
	'caption'=>$file['caption'],
	'reply_markup'=>json_encode([
    'inline_keyboard'=>[
        [['text'=>"❤️ ({$file['like']})",'callback_data'=>"like_$match[2]"]],
              ]
        ])
    ]);	
	elseif($file['download'] < $file['limit']){
	jijibot('sendDocument',[
	'chat_id'=>$from_id,
	'document'=>$file['file'],
	'caption'=>$file['caption'],
	'reply_markup'=>json_encode([
    'inline_keyboard'=>[
        [['text'=>"❤️ ({$file['like']})",'callback_data'=>"like_$match[2]"]],
              ]
        ])
    ]);
	$download = $file['download'] + 1;
	jijibot('editMessageReplyMarkup',[
    'chat_id'=>"@$channel",
    'message_id'=>$match[2],
	'reply_markup'=>json_encode([
    'inline_keyboard'=>[
			[['text'=>'📂 دریافت سورس','url'=>"https://t.me/$usernamebot?start=file_$match[2]"]],
			[['text'=>"📥 تعداد دانلود رایگان : $download از {$file['limit']}",'callback_data'=>'download']],
			[['text'=>"❤️ ({$file['like']})",'callback_data'=>"like_$match[2]"],['text'=>"🤖 ربات $botname",'url'=>"https://t.me/$usernamebot?start=start"]],
              ]
        ])
    		]);
    $connect->query("UPDATE `file` SET `download` = '$download' WHERE `id` = '$match[2]' LIMIT 1");
	$connect->query("INSERT INTO `download` (`id` , `file`) VALUES ('$from_id' , '$match[2]')");
	}
	elseif($user['coin'] > 0){
	jijibot('sendDocument',[
	'chat_id'=>$from_id,
	'document'=>$file['file'],
	'caption'=>$file['caption'],
	'reply_markup'=>json_encode([
    'inline_keyboard'=>[
        [['text'=>"❤️ ({$file['like']})",'callback_data'=>"like_$match[2]"]],
              ]
        ])
    ]);
	$connect->query("INSERT INTO `download` (`id` , `file`) VALUES ('$from_id' , '$match[2]')");
	$connect->query("UPDATE `user` SET `coin` = coin - 1 WHERE `id` = '$from_id' LIMIT 1");
	}else
	jijibot('sendmessage',[
	'chat_id'=>$from_id,
	'text'=>"❗️ ظرفیت دانلود رایگان این سورس به پایان رسیده است و نمیتوانید سورس را رایگان دریافت کنید

☑️ شما میتوانید با افزایش سکه های حساب خود اقدام به دریافت سورس ها بدون محدودیت کنید
👈🏻 با دریافت هر سورس که ظرفیت دانلود رایگان آن به پایان رسیده است یک سکه از شما کسر خواهد شد

👇🏻 از منوی پایین انتخاب کنید",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$home
            ]);
	}else
		 jijibot('sendmessage',[
        'chat_id'=>$from_id,
        'text'=>"☑️ برای استفاده از ربات « $botname » ابتدا باید وارد کانال  « $channelname » شوید
❗️ برای دریافت سورس ها ، اطلاعیه ها و گزارشات شما باید عضو کانال ربات شوید
		
📣 @$channel

👈🏻 بعد از عضویت مجدد به کانال برگشته و اقدام به دریافت سورس کنید",
       'reply_to_message_id'=>$message_id,
       'reply_markup'=>$home
			]);	
   if($user['id'] != true)
   $connect->query("INSERT INTO `user` (`id`) VALUES ('$from_id')");
} 
elseif(preg_match('/^(\/start) (.*)/', $text , $match) and $user['id'] != true and $match[2] > 0){
	if(jijibot('getChatMember',['chat_id'=>"@$channel",'user_id'=>$from_id])->result->status != 'left'){
	jijibot('sendmessage',[
	'chat_id'=>$from_id,
	'text'=>"🌹 سلام $first_name عزیز به $botname خوش آمدید

$maintext",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$home
    		]);
   $connect->query("INSERT INTO `user` (`id`) VALUES ('$from_id')");
   $user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$match[2]' LIMIT 1"));
   $member = $user['member'] + 1;
   $coin = $user['coin'] + 1;
   jijibot('sendmessage',[
	'chat_id'=>$match[2],
	'text'=>"🌟 تبریک ! کاربر [$from_id](tg://user?id=$from_id) با استفاده از لینک دعوت شما وارد ربات شده	
⬆️ یک سکه به سکه حساب شما افزوده شده

💰 موجودی حساب : $coin سکه
👥 تعداد زیر مجموعه : $member نفر",
	'parse_mode'=>'Markdown',
	  	]);
   $connect->query("UPDATE `user` SET `member` = '$member' , `coin` = '$coin' WHERE `id` = '$match[2]' LIMIT 1");
   }else{
     jijibot('sendmessage',[
        'chat_id'=>$from_id,
        'text'=>"☑️ برای استفاده از ربات « $botname » ابتدا باید وارد کانال  « $channelname » شوید
❗️ برای دریافت سورس ها ، اطلاعیه ها و گزارشات شما باید عضو کانال ربات شوید
		
📣 @$channel

👇 بعد از عضویت در کانال روی دکمه « ✅ تایید عضویت » بزنید 👇",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
			[['text'=>'✅ تایید عضویت','callback_data'=>'join']],
              ]
        ])
			]);	 
   $connect->query("INSERT INTO `user` (`id` , `step`) VALUES ('$from_id' , 'send $match[2]')");
   }
}   
//===========================// back //===========================
elseif($text == '🔙 بازگشت'){
    jijibot('sendmessage',[
	'chat_id'=>$from_id,
	'text'=>"⬅️ به منوی اصلی بازگشتید
	
$maintext",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$home
            ]);
  $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
}
//===========================// join //===========================
elseif(jijibot('getChatMember',['chat_id'=>"@$channel",'user_id'=>$from_id])->result->status == 'left'){
 jijibot('sendmessage',[
        'chat_id'=>$from_id,
        'text'=>"☑️ برای استفاده از ربات « $botname » ابتدا باید وارد کانال  « $channelname » شوید
❗️ برای دریافت سورس ها ، اطلاعیه ها و گزارشات شما باید عضو کانال ربات شوید
		
📣 @$channel

👇 بعد از عضویت در کانال روی دکمه « ✅ تایید عضویت » بزنید 👇",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
			[['text'=>'✅ تایید عضویت','callback_data'=>'join']],
              ]
        ])
			]);
if($user['id'] != true)
$connect->query("INSERT INTO `user` (`id`) VALUES ('$from_id')");
}
//========================== // key // ==============================
elseif($text == '🔍 جست و جو سورس'){
jijibot('sendmessage',[
	'chat_id'=>$from_id,
	'text'=>"👇🏻 جهت جست و جوی سورس مورد نظر خود لطفا نام محصول را ارسال کنید
	
👈🏻 با دریافت هر سورس که ظرفیت دانلود رایگان آن به پایان رسیده است یک سکه از شما کسر خواهد شد
👈🏻 جهت مشاهده لیست کامل سورس ها کافیست به « @$channel » مراجعه کنید",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back,
            ]);	
   $connect->query("UPDATE `user` SET `step` = 'search' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($text == '📊 جدیدترین ها'){
 $file = mysqli_query($connect,"SELECT * FROM `file` ORDER BY `id` DESC LIMIT 20");
 while($row = mysqli_fetch_assoc($file)){
 $name = explode("\n",$row['caption']);
 $result = $result."نام سورس : $name[0]\n❤️ تعداد لایک : {$row['like']}\n📥 دریافت سورس : /file_{$row['id']}\n\n";
 }
    jijibot('sendmessage',[
	'chat_id'=>$from_id,
	'text'=>"🗂 لیست 20 سورس اخیر اضافه شده به ربات و کانال
	
$result
━ ━ ━ ━
👈🏻 جهت مشاهده لیست کامل سورس ها کافیست به « @$channel » مراجعه کنید
👈🏻 شما میتوانید با افزایش سکه های حساب خود اقدام به دریافت سورس ها بدون محدودیت کنید",
    'reply_to_message_id'=>$message_id,
            ]);	
}
elseif($text == '❤️ محبوب ترین ها'){
 $file = mysqli_query($connect,"SELECT * FROM `file` ORDER BY `like` DESC LIMIT 18");
 while($row = mysqli_fetch_assoc($file)){
 $name = explode("\n",$row['caption']);
 $result = $result."نام سورس : $name[0]\n❤️ تعداد لایک : {$row['like']}\n📥 دریافت سورس : /file_{$row['id']}\n\n";
 }
    jijibot('sendmessage',[
	'chat_id'=>$from_id,
	'text'=>"♥️ لیست سورس های محبوب در ربات از نطر تعداد لایک
	
$result
━ ━ ━ ━
👈🏻 جهت مشاهده لیست کامل سورس ها کافیست به « @$channel » مراجعه کنید
🎁 با دعوت دوستان به ربات با لینک اختصاصی خود میتوانید به ازای هر نفر 1 سکه دریافت کنید",
    'reply_to_message_id'=>$message_id,
            ]);	
}
elseif($text == '👤 حساب کاربری'){
  $file = mysqli_num_rows(mysqli_query($connect,"select `id` from `download` WHERE `id` = '$from_id'"));
  $like = mysqli_num_rows(mysqli_query($connect,"select `id` from `like` WHERE `id` = '$from_id'"));
  jijibot('sendmessage',[
	'chat_id'=>$from_id,
	'text'=>"👤 حساب کاربری شما در $botname :

🆔 شناسه : $from_id
🗣 نام : $first_name

💰 موجودی حساب : {$user['coin']} سکه
👥 تعداد زیر مجموعه : {$user['member']} نفر

📁 تعداد فایل دریافت شده : $file
👍🏻 تعداد لایک انجام شده : $like

👈🏻 جهت ارسال سورس خود به کانال کافیست به پشتیبانی مراجعه کنید

👈🏻 با دریافت هر سورس که ظرفیت دانلود رایگان آن به پایان رسیده است 1 سکه از شما کسر خواهد شد
👈🏻 شما میتوانید با افزایش سکه های حساب خود اقدام به دریافت سورس ها بدون محدودیت کنید",
'reply_to_message_id'=>$message_id,
            ]);					
}
elseif($text == '➕ افزایش سکه'){
jijibot('sendmessage',[
	'chat_id'=>$from_id,
	'text'=>"👇🏻 یکی از بخش های زیر را جهت افزایش سکه انتخاب کنید	
💰 سکه حساب شما : {$user['coin']} تومان

👈🏻 با دریافت هر سورس که ظرفیت دانلود رایگان آن به پایان رسیده است یک سکه از شما کسر خواهد شد
	
🗣 با دعوت دوستان خود به ربات با لینک اختصاصی خود میتوانید به ازای هر نفر 1 سکه دریافت کنید
ℹ️ جهت افزایش سکه به مبلغ دلخواه به صورت آنلاین میتوانید از خرید سکه استفاده کنید",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
        'keyboard'=>[
		[['text'=>'🗣 دعوت دیگران'],['text'=>'💳 خرید سکه']],
		[['text'=>'🔙 بازگشت']],
		],
        'resize_keyboard'=>true,
       		])
            ]);					
}	
elseif($text == '💳 خرید سکه'){
    jijibot('sendmessage',[
	'chat_id'=>$from_id,
	'text'=>"👇🏻 لطفا تعداد سکه مورد نظر خود را به عدد وارد کنید
❗️ توجه کنید که حداکثر میتوانید 500 سکه حساب خود را شارژ کنید

👈🏻 تعرفه هر 1 سکه 500 تومان است",
   'reply_to_message_id'=>$message_id,
   'reply_markup'=>json_encode([
        'keyboard'=>[
		[['text'=>'🔙 بازگشت']],
		],
        'resize_keyboard'=>true,
       		])
            ]);
$connect->query("UPDATE `user` SET `step` = 'pay' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($text == '🗣 دعوت دیگران'){
	$id = jijibot('sendphoto',[
	'chat_id'=>$from_id,
	'photo'=>$baner,
	'caption'=>"📢 کانال $channelname مرجع انواع سورس کد های مختلف

✅ سورس انواع ربات ها , قالب ها و اسکریپت های تست شده و حرفه ای
🌟 هر روز کلی سورس کد و اسکریپت منتظر شماست !

👇🏻 برای دریافت سورس ها کافیه از این ربات فوق العاده استفاده کنی

t.me/$usernamebot?start=$from_id",
    		])->result->message_id;
    jijibot('sendmessage',[
	'chat_id'=>$from_id,
	'text'=>"👆🏻 بنر بالا حاوی لینک دعوت شما به ربات است
	
🎁 با دعوت دوستان به ربات با لینک اختصاصی خود میتوانید به ازای هر نفر 1 سکه دریافت کنید
☑️ پس با زیرمجموعه گیری به راحتی میتوانید سکه حساب خود را رایگان! افزایش دهید

❗️ توجه کنید که زیر مجموعه های شما برای دریافت سکه رایگان حتما باید در کانال ما عضو شوند

💰 موجودی حساب : {$user['coin']} سکه
👥 تعداد زیر مجموعه : {$user['member']} نفر",
	'reply_to_message_id'=>$id,
    		]);
}
elseif($text == '☎️ پشتیبانی'){
jijibot('sendmessage',[
	'chat_id'=>$from_id,
	'text'=>"👮🏻 همکاران ما در خدمت شما هستن

📨 جهت ارتباط به صورت مستقیم 👈🏻 $usernamesup	
⚖️ کاربر گرامی، چنانچه شما از ربات $botname استفاده نمایید به منزله قبول قوانین است
 
• سعی بخش پشتیبانی بر این است که تمامی پیام های دریافتی در کمتر از ۱۲ ساعت پاسخ داده شوند، بنابراین تا زمان دریافت پاسخ صبور باشید

• لطفا پیام، سوال، پیشنهاد و یا انتقاد خود را در قالب یک پیام واحد به طور کامل ارسال کنید 👇🏻",
     'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);
$connect->query("UPDATE `user` SET `step` = 'sup' WHERE `id` = '$from_id' LIMIT 1");	
}
elseif($text == 'ℹ️ راهنما'){
jijibot('sendmessage',[
	'chat_id'=>$from_id,
	'text'=>"📢 کانال $channelname مرجع انواع سورس کد های مختلف
📂 بانک انواع سورس کد های مختلف به صورت کاملا تست شده

✅ سورس انواع ربات ها , قالب ها و اسکریپت های تست شده و حرفه ای

☑️ با ما همراه باشید و مارو به دوستاتون معرفی کنید 
🌟 هر روز کلی سورس کد و اسکریپت منتظر شماست !

👈🏻 جهت مشاهده لیست کامل سورس ها کافیست به « @$channel » مراجعه کنید
👈🏻 جهت ارسال سورس خود به کانال کافیست به پشتیبانی مراجعه کنید

👈🏻 با دریافت هر سورس که ظرفیت دانلود رایگان آن به پایان رسیده است 1 سکه از شما کسر خواهد شد
👈🏻 شما میتوانید با افزایش سکه های حساب خود اقدام به دریافت سورس ها بدون محدودیت کنید

🎁 با دعوت دوستان به ربات با لینک اختصاصی خود میتوانید به ازای هر نفر 1 سکه دریافت کنید
ℹ️ جهت افزایش سکه به مبلغ دلخواه به صورت آنلاین میتوانید از خرید سکه استفاده کنید

👈🏻 تعرفه هر 1 سکه 500 تومان است
❤️ توجه کنید که در صورت لایک یک سورس در پیوی ربات , تغییرات در کانال به صورت همگانی اعمال خواهد شد

♥️ راهنمای ربات به پایان رسید , در صورت داشتن هر نوع پیشنهاد یا انتقاد از دکمه پشتیبانی استفاده کنید . حضور شما تنها دلگرمی ماست، مارو از حضورتون بی نصیب نذارید .

🤖 ارتباط با ما و دریافت سورس ها : @$usernamebot
👈🏻 کانال $channelname : @$channel",
'reply_to_message_id'=>$message_id,
            ]);
}		
elseif(preg_match('/^\/file_(.*)/', $text , $match)){
	$query = mysqli_query($connect,"SELECT * FROM `file` WHERE `id` = '$match[1]' LIMIT 1");
    if(mysqli_num_rows($query) > 0){
	$file = mysqli_fetch_assoc($query);
	jijibot('sendphoto',[
	'chat_id'=>$from_id,
	'photo'=>$file['photo'],
	'caption'=>$file['caption'],
	'reply_markup'=>json_encode([
    'inline_keyboard'=>[
			[['text'=>'📂 دریافت سورس','url'=>"https://t.me/$usernamebot?start=file_$match[1]"]],
			[['text'=>"📥 تعداد دانلود رایگان : {$file['download']} از {$file['limit']}",'callback_data'=>'download']],
			[['text'=>"❤️ ({$file['like']})",'callback_data'=>"like_$match[1]"],['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]],
              ]
        ])
    ]);
	}else
	jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❌ خطا ، محصول مورد نظر شما یافت نشد',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$home,
    	   ]);	
}
//===========================// data //===========================
elseif($data == 'join'){
if(jijibot('getChatMember',['chat_id'=>"@$channel",'user_id'=>$fromid])->result->status != 'left'){
	jijibot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"☑️ عضویت شما در کانال تایید شد

$maintext",
'reply_to_message_id'=>$messageid,
     'reply_markup'=>$home
    		]);
   }else{
       jijibot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "❌ هنوز داخل کانال « @$channel » عضو نیستی",
            'show_alert' =>true
        ]);
}
}	
elseif($data == 'download'){
      jijibot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => '❗️ این دکمه جهت نمایش تعداد محدودیت دانلود این سورس است 
👈🏻 شما میتوانید با افزایش سکه های حساب خود در ربات اقدام به دریافت سورس ها بدون محدودیت کنید',
            'show_alert' =>true
        ]);
}
elseif(preg_match('/^like_(.*)/', $data , $match)){
  if(mysqli_num_rows(mysqli_query($connect,"SELECT * FROM `like` WHERE `file` = '$match[1]' AND `id` = '$fromid' LIMIT 1")) <= 0){
	jijibot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => '❤️ لایک شما با موفقیت انجام شد',
			'show_alert' =>true
              ]);
	$file = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `file` WHERE `id` = '$match[1]' LIMIT 1"));
	$like = $file['like'] + 1;
	jijibot('editMessageReplyMarkup',[
    'chat_id'=>"@$channel",
    'message_id'=>$match[1],
	'reply_markup'=>json_encode([
    'inline_keyboard'=>[
			[['text'=>'📂 دریافت سورس','url'=>"https://t.me/$usernamebot?start=file_$match[1]"]],
			[['text'=>"📥 تعداد دانلود رایگان : {$file['download']} از {$file['limit']}",'callback_data'=>'download']],
			[['text'=>"❤️ ($like)",'callback_data'=>"like_$match[1]"],['text'=>"🤖 ربات $botname",'url'=>"https://t.me/$usernamebot?start=start"]],
              ]
        ])
    		]);
	$connect->query("UPDATE `file` SET `like` = '$like' WHERE `id` = '$match[1]' LIMIT 1");
	$connect->query("INSERT INTO `like` (`id` , `file`) VALUES ('$fromid' , '$match[1]')");
  }else
      jijibot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => '❗️ شما قبلا این سورس را لایک کرده اید',
            'show_alert' =>true
        ]);
}
//===========================// step //===========================
elseif($user['step'] == 'search' && $tc == 'private'){
      $file = mysqli_query($connect,"SELECT * FROM `file` WHERE `caption` like '%$text%'");
      if(mysqli_num_rows($file) > 0){
      while($row = mysqli_fetch_assoc($file))
	jijibot('sendphoto',[
	'chat_id'=>$from_id,
	'photo'=>$row['photo'],
	'caption'=>$row['caption'],
	'reply_markup'=>json_encode([
    'inline_keyboard'=>[
			[['text'=>'📂 دریافت سورس','url'=>"https://t.me/$usernamebot?start=file_{$row['id']}"]],
			[['text'=>"📥 تعداد دانلود رایگان : {$row['download']} از {$row['limit']}",'callback_data'=>'download']],
			[['text'=>"❤️ ({$row['like']})",'callback_data'=>"like_{$row['id']}"],['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]],
              ]
        ])
    ]);
	  		jijibot('sendmessage',[       
			'chat_id'=>$from_id,
			'text'=>'👆🏻 جست و جو به پایان رسید , نتایج مرتبط برای شما ارسال شد',
			'reply_markup'=>$home
	        ]);	
     $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}else
			jijibot('sendmessage',[       
			'chat_id'=>$from_id,
			'text'=>'❗️ خطا ، محصول مرتبطی با عبارت مورد نظر شما یافت نشد',
			'reply_to_message_id'=>$message_id,
			'reply_markup'=>$back
	              ]);	
}
elseif($user['step'] == 'pay' && $tc == 'private'){
if($text > 0 and $text <= 500){
	        $amount = $text * 500;
			jijibot('sendmessage',[       
			'chat_id'=>$from_id,
			'text'=>'⏳ در حال ساخت فاکتور پرداخت ...',
			'reply_markup'=>$home
	        ]);	
			jijibot('sendmessage',[       
			'chat_id'=>$from_id,
			'text'=>"✅ فاکتور افزایش $text سکه با مبلغ $amount تومان با موفقیت برای شما ساخته شد
			
☑️ تمامی پرداخت ها به صورت اتوماتیک بوده و پس از تراکنش موفق مبلغ آن به سکه حساب شما در ربات افزوده خواهد شد .

👇🏻 پرای پرداخت کافیست از دکمه زیر استفاده کنید",
			'reply_to_message_id'=>$message_id,
			'reply_markup'=>json_encode([
            'inline_keyboard'=>[
	          [['text'=>"💳 پرداخت $amount تومان",'url'=>"$web/pay?amount=$amount&id=$from_id"]],
              ]
              ])
	       ]);	
     $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}else
			jijibot('sendmessage',[       
			'chat_id'=>$from_id,
			'text'=>'❗️ خطا ، پیام شما دارای عدد ورودی نادرست است
			
👇🏻 لطفا تعداد سکه مورد نظر خود را به عدد وارد کنید
❗️ توجه کنید که حداکثر میتوانید 500 سکه حساب خود را شارژ کنید',
			'reply_to_message_id'=>$message_id,
			'reply_markup'=>$back
	              ]);	
}
elseif($user['step'] == 'sup'){
	    jijibot('sendmessage',[       
		'chat_id'=>$from_id,
		'text'=>'✅ پیام شما با موفقیت ارسال شد منتظر پاسخ پشتیبانی باشید',
        'reply_to_message_id'=>$message_id,
        'reply_markup'=>$back
	       ]);	
        jijibot('ForwardMessage',[
        'chat_id'=>$admin[0],
        'from_chat_id'=>$from_id,
        'message_id'=>$message_id
           ]);
}
//===========================// panel admin //===========================
elseif($text == '/panel' and $tc == 'private' and in_array($from_id,$admin)){
   jijibot('sendmessage',[
   'chat_id'=>$from_id,
   'text'=>"📍 ادمین عزیز به پنل مدریت ربات خوش امدید",
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"📍 آمار ربات"],['text'=>"📍 مسدود کردن"]],
       [['text'=>"📍 ارسال به کاربران"],['text'=>"📍 فروارد به کاربران"]],
	   [['text'=>"📍 حذف سورس"],['text'=>"📍 ارسال سورس"]],
	   [['text'=>"📍 ارسال سکه"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
}
elseif($text == 'برگشت 🔙' and $tc == 'private' and in_array($from_id,$admin)){
    jijibot('sendmessage',[
   'chat_id'=>$from_id,
   'text'=>"📍 به منوی مدیریت بازگشتید",
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"📍 آمار ربات"],['text'=>"📍 مسدود کردن"]],
       [['text'=>"📍 ارسال به کاربران"],['text'=>"📍 فروارد به کاربران"]],
	   [['text'=>"📍 حذف سورس"],['text'=>"📍 ارسال سورس"]],
	   [['text'=>"📍 ارسال سکه"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif($text == '📍 آمار ربات' and $tc == 'private' and in_array($from_id,$admin)){
$alluser = mysqli_num_rows(mysqli_query($connect,"select `id` from `user`"));
$allfile = mysqli_num_rows(mysqli_query($connect,"select `id` from `file`"));
$alldownload = mysqli_num_rows(mysqli_query($connect,"select `id` from `download`"));
$alllike = mysqli_num_rows(mysqli_query($connect,"select `id` from `like`"));
		jijibot('sendmessage',[
		'chat_id'=>$from_id,
		'text'=>"🤖 آمار ربات شما
		
📍 تعداد کاربران : $alluser
📍 تعداد فایل : $allfile
📍 تعداد دانلود : $alldownload
📍 تعداد لایک : $alllike",
		]);
		}
elseif ($text == '📍 ارسال به کاربران' and $tc == 'private' and in_array($from_id,$admin)) {
         jijibot('sendmessage',[
         'chat_id'=>$from_id,
         'text'=>"📍 لطفا متن یا رسانه خود را ارسال کنید [میتواند شامل عکس باشد]  همچنین میتوانید رسانه را همراه با کشپن [متن چسپیده به رسانه ارسال کنید]",
	     'reply_markup'=>json_encode([
         'keyboard'=>[
	         [['text'=>"برگشت 🔙"]]
                ],
           'resize_keyboard'=>true
              ])
          ]);
$connect->query("UPDATE `user` SET `step` = 'sendtoall' WHERE `id` = '$from_id' LIMIT 1");
}
elseif ($text == '📍 فروارد به کاربران' and $tc == 'private' and in_array($from_id,$admin)){
         jijibot('sendmessage',[
         'chat_id'=>$from_id,
         'text'=>"📍 لطفا پیام خود را فوروارد کنید [پیام فوروارد شده میتوانید از شخص یا کانال باشد]",
	     'reply_markup'=>json_encode([
         'keyboard'=>[
	         [['text'=>"برگشت 🔙"]]
                ],
           'resize_keyboard'=>true
              ])
          ]);
$connect->query("UPDATE `user` SET `step` = 'fortoall' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif ($text == '📍 مسدود کردن' and $tc == 'private' and in_array($from_id,$admin)){
         jijibot('sendmessage',[
         'chat_id'=>$from_id,
         'text'=>"📍 لطفا شناسه کاربری فرد را ارسال کنید",
	   'reply_markup'=>json_encode([
       'keyboard'=>[
	        [['text'=>"برگشت 🔙"]]
                 ],
          'resize_keyboard'=>true
            ])
          ]);
$connect->query("UPDATE `user` SET `step` = 'block' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif ($text == '📍 ارسال سورس' and $tc == 'private' and in_array($from_id,$admin)){
         jijibot('sendmessage',[
         'chat_id'=>$from_id,
         'text'=>"📍 لطفا بنر سورس و متن زیر بنر و فایل سورس را ارسال کنید",
	   'reply_markup'=>json_encode([
       'keyboard'=>[
	        [['text'=>"برگشت 🔙"]]
                 ],
          'resize_keyboard'=>true
            ])
          ]);
$connect->query("UPDATE `user` SET `step` = 'sendbaner' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif ($text == '📍 حذف سورس' and $tc == 'private' and in_array($from_id,$admin)){
         jijibot('sendmessage',[
         'chat_id'=>$from_id,
         'text'=>"📍 لطفا شناسه سورس را ارسال کنید",
	   'reply_markup'=>json_encode([
       'keyboard'=>[
	        [['text'=>"برگشت 🔙"]]
                 ],
          'resize_keyboard'=>true
            ])
          ]);
$connect->query("UPDATE `user` SET `step` = 'deletefile' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif ($text == '📍 ارسال سکه' and $tc == 'private' and in_array($from_id,$admin)){
         jijibot('sendmessage',[
         'chat_id'=>$chat_id,
         'text'=>"📍 لطفا در خط اول ایدی فرد و در خط دوم میزان موجودی را وارد کنید
📍 اگر میخواهید موجودی فر را کم کنید از علامت - منفی استفاده کنید
267785153
20",
	   'reply_markup'=>json_encode([
       'keyboard'=>[
	        [['text'=>"برگشت 🔙"]]
                 ],
          'resize_keyboard'=>true
            ])
          ]);
$connect->query("UPDATE `user` SET `step` = 'sendadmin' WHERE `id` = '$from_id' LIMIT 1");		
}
//===========================// admin step //===========================
elseif($user['step'] == 'sendbaner') {
     $photo = end($message->photo)->file_id;	 
     $caption = $message->caption;	
			jijibot('sendmessage',[       
			'chat_id'=>$from_id,
			'text'=>"📍 لطفا فایل اصلی سورس را ارسال کنید",
	         ]);		 	
    $connect->query("UPDATE `user` SET `step` = 'sendfile' WHERE `id` = '$from_id' LIMIT 1");
	$connect->query("UPDATE `sendfile` SET `data` = '$photo^$caption' LIMIT 1");
}
elseif($user['step'] == 'sendfile') {
    $file = $message->document->file_id;	
			jijibot('sendmessage',[       
			'chat_id'=>$from_id,
			'text'=>"📍 لطفا محدودیت تعداد دانلود را ارسال کنید",
	         ]);		 	
    $connect->query("UPDATE `user` SET `step` = 'sendlimit' WHERE `id` = '$from_id' LIMIT 1");
	$connect->query("UPDATE `sendfile` SET `data` = CONCAT(`data`,'^$file') LIMIT 1");
}
elseif($user['step'] == 'sendlimit') {
			jijibot('sendmessage',[       
			'chat_id'=>$from_id,
			'text'=>"📍 سورس با موفقیت به کانال @$channel ارسال شد",
	         ]);	
    $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
	$file = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `sendfile` LIMIT 1"));
	$explode = explode('^',$file['data']);
	$getfile = jijibot('getfile', ['file_id' => $explode[0]])->result->file_path;
	$stamp = imagecreatefrompng('lib/logo.png');
    $im = imagecreatefromjpeg("https://api.telegram.org/file/bot" . API_KEY . "/$getfile");
    $marge_right = 10;
    $marge_bottom = 10;
    $sx = imagesx($stamp);
    $sy = imagesy($stamp);
    imagecopy($im, $stamp, imagesx($im) - $sx - $marge_right, imagesy($im) - $sy - $marge_bottom, 0, 0, imagesx($stamp), imagesy($stamp));
    imagepng($im , 'photo.png');
    imagedestroy($im);
    $id = jijibot('sendphoto',[
	'chat_id'=>"@$channel",
	'photo'=>new CURLFile('photo.png'),
	'caption'=>$explode[1],
	'reply_markup'=>json_encode([
    'inline_keyboard'=>[
			[['text'=>'📂 دریافت سورس','url'=>"https://t.me/$usernamebot?start=file"]],
			[['text'=>"📥 تعداد دانلود رایگان : 0 از $text",'callback_data'=>'download']],
			[['text'=>"❤️ (0)",'callback_data'=>"like"],['text'=>"🤖 ربات $botname",'url'=>"https://t.me/$usernamebot?start=start"]],
              ]
        ])
    ])->result;	 
	jijibot('editMessageReplyMarkup',[
    'chat_id'=>"@$channel",
    'message_id'=>$id->message_id,
	'reply_markup'=>json_encode([
    'inline_keyboard'=>[
            [['text'=>'📂 دریافت سورس','url'=>"https://t.me/$usernamebot?start=file_{$id->message_id}"]],
			[['text'=>"📥 تعداد دانلود رایگان : 0 از $text",'callback_data'=>'download']],
			[['text'=>"❤️ (0)",'callback_data'=>"like_{$id->message_id}"],['text'=>"🤖 ربات $botname",'url'=>"https://t.me/$usernamebot?start=start"]],
              ]
        ])
    		]);
	$connect->query("INSERT INTO `file` (`id` , `file` , `photo` , `caption` , `limit`) VALUES ('{$id->message_id}' , '$explode[2]' , '".end($id->photo)->file_id."' , '$explode[1]' , '$text')");
}
elseif($user['step'] == 'deletefile' && $tc == 'private') {
			jijibot('sendmessage',[       
			'chat_id'=>$from_id,
			'text'=>"✅ با موفقیت حذف شد",
	         ]);	
$connect->query("DELETE FROM `file` WHERE id = '$text'");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($user['step'] == 'block' && $tc == 'private') {
			jijibot('sendmessage',[       
			'chat_id'=>$from_id,
			'text'=>"✅ فرد با موفقیت مسدود شد",
	         ]);	
$connect->query("INSERT INTO `block` (`id`) VALUES ('$text')");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($user['step'] == 'sendadmin') {
$all = explode("\n", $text);	
			jijibot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"انتقال موجودی با موفقیت انجام شد ✅",
	         ]);
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$all[0]' LIMIT 1"));			 
$coin = $user['coin'] + $all[1] ;
			jijibot('sendmessage',[       
			'chat_id'=>$all[0],
			'text'=>"✅ $all[1] سکه  از طرف مدیریت ربات برای شما انتقال داده شد .
💰 موجودی جدید شما : $coin سکه",
	]);	
$connect->query("UPDATE `user` SET `coin` = '$coin' WHERE `id` = '$all[0]' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif ($user['step'] == 'sendtoall') {
$photo = $message->photo[count($message->photo)-1]->file_id;
$caption = $update->message->caption;
         jijibot('sendmessage',[
        	'chat_id'=>$from_id,
        	'text'=>"✔️ پیام شما با موفقیت برای ارسال همگانی تنظیم شد",
 ]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `sendall` SET step = 'send' , `text` = '$text$caption' , `chat` = '$photo' LIMIT 1");			
}
elseif ($user['step'] == 'fortoall') {
         jijibot('sendmessage',[
        	'chat_id'=>$from_id,
        	'text'=>"✔️ پیام شما با موفقیت به عنوان فوروارد همگانی تنظیم شد",
 ]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `sendall` SET `step` = 'forward' , `text` = '$message_id' , `chat` = '$from_id' LIMIT 1");		
}
//===========================// answer //===========================
elseif($message->text && $message->reply_to_message && $from_id == $admin[0]){
	jijibot('sendmessage',[
        'chat_id'=>$from_id,
        'text'=>'☑️ پاسخ شما برای فرد ارسال شد'
		]);
	jijibot('sendmessage',[
        'chat_id'=>$message->reply_to_message->forward_from->id,
        'text'=>"👮🏻 پاسخ پشتیبان برای شما : $text",
		]);
}
//===========================// main //===========================
elseif($message){
	jijibot('sendmessage',[
	'chat_id'=>$from_id,
	'text'=>$maintext,
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$home
    		]);
if($user['id'] != true)
$connect->query("INSERT INTO `user` (`id`) VALUES ('$from_id')");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
//===========================// coin join //===========================	
if(preg_match('/^send (.*)/', $user['step'] , $match)){
   if(jijibot('getChatMember',['chat_id'=>"@$channel",'user_id'=>$user['id']])->result->status != 'left'){
   $data = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$match[1]' LIMIT 1"));
   $member = $data['member'] + 1;
   $coin = $data['coin'] + 1;
   jijibot('sendmessage',[
	'chat_id'=>$match[1],
	'text'=>"🌟 تبریک ! کاربر [{$user['id']}](tg://user?id={$user['id']}) با استفاده از لینک دعوت شما وارد ربات شده	
⬆️ یک سکه به سکه حساب شما افزوده شده

💰 موجودی حساب : $coin سکه
👥 تعداد زیر مجموعه : $member نفر",
	'parse_mode'=>'Markdown',
	  	]);
   $connect->query("UPDATE `user` SET `member` = '$member' , `coin` = '$coin' WHERE `id` = '$match[1]' LIMIT 1");
   $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '{$user['id']}' LIMIT 1");
   }
}
?>