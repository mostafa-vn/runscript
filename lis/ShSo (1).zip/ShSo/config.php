<?php
/* * * * * * * * * * * 
In The Name of God 
Source Of Shahre Source
By PHP And Mysql
V.1
* * * * * * * * * *
Developer : MohammadReza Jafari
Telegram : @MohammadRezajiji
Phone : 09392287037
* * * * * * * * * * */
error_reporting(0);
//========================== // token // ==============================
define('API_KEY','1054426356:AAGMr5crPbZJYY6ERAyjGXuSNu8c80WjHF8');
//========================== // config // ==============================
$admin = ['267785153']; // ها را ماننده این الگورتیم بگذارید ادمین اصلی ایدی اول است
$usernamebot = 'ShahreSourceBot'; // یوزرنیم ربات
$channel = 'ShahreSource'; // ایدی کانال بدون @
$channelname = 'شهر سورس'; // نام کانال برای نمایش
$botname = 'شهر سورس'; // نام ربات برای نمایش
$web = 'http://source-home.ir/bot/ShSo'; // آدرس محل قرار گیری سورس
$MerchantID = 'a08a1332-48ef-11e7-a2ea-005056a205be'; // مرچند کد درگاه
$usernamesup = '@MohammadRezajiji'; // ایدی فرد پشتیبان ربات
$baner = 'https://t.me/justfortestjiji/1110'; // بنر زیر مجموعه گیری
//========================== // database // ==============================
$connect = new mysqli('localhost','sourcehome_db','-x)~-anwHqjy','sourcehome_db');
$connect->query("SET NAMES 'utf8'"); $connect->set_charset('utf8mb4');
?>