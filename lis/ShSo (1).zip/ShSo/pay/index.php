<?php 
/* * * * * * * * * * * 
In The Name of God 
Source Of Shahre Source
By PHP And Mysql
V.1.2
* * * * * * * * * *
Developer : MohammadReza Jafari
Telegram : @MohammadRezajiji
Phone : 09392287037
* * * * * * * * * * */
//==================================================
include '../bot.php';
//====================//  Get  //==============================
$user = $_GET['id'];
$amount = $_GET['amount'];
//========================== // config // ==============================
$CallbackURL = "$web/pay/back.php?id=$user&amount=$amount"; // لینک برگشت خرید
$Description = "افزایش سکه $botname";
//==================================================
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentRequest([
'MerchantID' => $MerchantID,
'Amount' => $amount,
'Description' => $Description,
'Email' => $Email,
'Mobile' => $Mobile,
'CallbackURL' => $CallbackURL,
]);
//==============================================================
Header('Location: https://www.zarinpal.com/pg/StartPay/'.$result->Authority.'/ZarinGate');
?>