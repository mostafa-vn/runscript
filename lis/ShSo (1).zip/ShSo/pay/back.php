<?php
/* * * * * * * * * * * 
In The Name of God 
Source Of Shahre Source
By PHP And Mysql
V.1.2
* * * * * * * * * *
Developer : MohammadReza Jafari
Telegram : @MohammadRezajiji
Phone : 09392287037
* * * * * * * * * * */
include '../bot.php';
//==============================================================
$user = $_GET['id'];
$amount = $_GET['amount'];
$Authority = $_GET['Authority'];
$coin = $amount / 500;
//==============================================================
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification([
'MerchantID' => $MerchantID,
'Authority' => $Authority,
'Amount' => $amount,
]);
//==============================================================
if ($_GET['Status'] == 'OK' and $result->Status == 100){
$data = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$user' LIMIT 1"));
$pluscoin = $data['coin']  +  $coin;
jijibot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"✅ #پرداخت_موفق 
⬆️ با تشکر از خرید شما , سکه های حساب شما افزایش یافت

💰 موجودی جدید حساب : $pluscoin سکه
☑️ مبلغ پرداخت شده : $amount تومان",
	'reply_markup'=>$home
            ]);
$connect->query("UPDATE `user` SET `coin` = '$pluscoin' WHERE `id` = '$user' LIMIT 1");	
jijibot('sendmessage',[
	'chat_id'=>$admin[0],
	'text'=>"✅ #پرداخت موفق
	
💳 مبلغ خرید : $amount تومان
👤 کاربر : [$user](tg://user?id=$user)",
     'parse_mode'=>'Markdown',
            ]);
?>
<html>
	<head>
		<title>افزایش سکه | <?php echo $botname;?></title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
			<meta name="description" content="صفحه افزایش سکهِ حساب">
      <meta name="keywords" content="افزایش بازدید و لایک پست ها در تلگرام">
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="assets/css/rtl.css" />
		<link rel="icon" type="image/png" href="images/fav.png">
	</head>
	<body>
		<!-- Wrapper -->
			<div id="wrapper">
				<!-- Header -->
					<header id="header" class="alt">
						<h1>ربات <?php echo $botname;?></h1>
						<p>صفحه خرید سکه</p>
					</header>
				<!-- Main -->
					<div id="main">
					<!-- First Section -->
										<section id="intro" class="main">
								<div class="spotlight">
							        <div class="content">
										<header class="major">
											<h2>پرداخت شما با موفقیت انجام شد و سکه خریداری شده به حساب شما افزوده شد , برای ادامه به ربات مراجعه کنید .</h2>
										</header>
										<ul class="actions">
											<li><a href="<?php echo "https://t.me/$usernamebot";?>" class="button">برگشت به ربات</a></li>
										</ul>
									</div>
								</div>
							</section>
					</div>		
			</div>
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
	</body>
</html>
<?php 
} else {
?>
<html>
	<head>
		<title>افزایش سکه | <?php echo $botname;?></title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
			<meta name="description" content="صفحه افزایش سکهِ حساب">
      <meta name="keywords" content="افزایش بازدید و لایک پست ها در تلگرام">
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="assets/css/rtl.css" />
		<link rel="icon" type="image/png" href="images/fav.png">
	</head>
	<body>
		<!-- Wrapper -->
			<div id="wrapper">
				<!-- Header -->
					<header id="header" class="alt">
						<h1>ربات <?php echo $botname;?></h1>
						<p>صفحه خرید سکه</p>
					</header>
				<!-- Main -->
					<div id="main">
					<!-- First Section -->
										<section id="intro" class="main">
								<div class="spotlight">
							        <div class="content">
										<header class="major">
											<h2>پرداخت شما با موفقیت انجام نشد ! به ربات برگشته و مجدد اقدام به خرید کنید</h2>
										</header>
										<ul class="actions">
											<li><a href="<?php echo "https://t.me/$usernamebot";?>" class="button">برگشت به ربات</a></li>
										</ul>
									</div>
								</div>
							</section>
					</div>		
			</div>
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
	</body>
</html>
<?php 
}
?>