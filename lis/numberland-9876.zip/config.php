<?php
/* * * * * * * * * * * 
In The Name of God 
Source Of NumberLand
By PHP And Mysql
V.2
* * * * * * * * * *
Developer : filepick.ir
Telegram : @filepick
* * * * * * * * * * */
error_reporting(0);
date_default_timezone_set('Asia/Tehran'); 
//========================== // token // ==============================
define('API_KEY','737264077:AAFZVWBEs0G3_DQhsiAhmn_XFWMXvNAx8xM');
//========================== // config // ==============================
$admin = ['267785153','000000000','000000000']; // ایدی ادمین ها را ماننده این الگورتیم بگذارید ادمین اصلی ایدی اول است
$usernamebot = 'ivnumbot'; // یوزرنیم ربات api
$channel = 'filepick'; // ایدی کانال بدون @
$channelname = 'نامبرلند'; // نام کانال برای نمایش
$channelby = 'NuLand'; // ایدی کانال خرید ها بدون @
$web = 'https://bot.7license.ir/numberland/'; // آدرس محل قرار گیری سورس
$MerchantID = '123qweasdgklhl;;dglkopie'; // مرچند کد درگاه نکست پی
$apikey = '3524f7100419d52c213d2d328ac4e7e6'; // مرچند کد در سایت numberland.ir
$cardinfo = '💳 شماره کارت : 1234567887654321
👤 نام صاحب کارت : فایل پیک'; // مشخصات کارت بانکی خود را وارد کنید جهت پرداخت آفلاین
//========================== // database // ==============================
$username = 'license_numberland';
$password = 'UOV7CtTR0hHQRwZG9x';
$dbname = 'license_numberland';
$connect = mysqli_connect('localhost', $username, $password, $dbname);
//==================================
?>