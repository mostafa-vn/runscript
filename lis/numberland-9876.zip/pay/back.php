<?php
/* * * * * * * * * * * 
In The Name of God 
Source Of NumberLand
By PHP And Mysql
V.2
* * * * * * * * * *
Developer : filepick.ir
Telegram : @filepick
* * * * * * * * * * */
include '../bot.php';
//==============================================================
$user = $_GET['id'];
$amount = $_GET['amount'];
$trans_id = $_POST['trans_id'];
//==============================================================
$client = new SoapClient('http://api.nextpay.org/gateway/verify.wsdl');  
$verify_obj = $client->PaymentVerification(array("api_key"=>$MerchantID ,"order_id"=> 1 ,"amount"=>$amount,"trans_id"=>$trans_id)); 
$code = $verify_obj->PaymentVerificationResult->code;
//==============================================================
if($code == 0 and mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `pay` WHERE `id` = '$trans_id' LIMIT 1")) != true){
$connect->query("INSERT INTO `pay` (`id`) VALUES ('$trans_id')");
$userdata = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE id = '$user' LIMIT 1"));
$pluscoin = $userdata["amount"]  +  $amount;
jijibot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"✅ #پرداخت_موفق با تشکر از خرید شما
🗣 موجودی حساب شما با موفقیت افزایش  یافت , در صورت وجود هر گونه ایراد کافیست با پشتیبانی در تماس باشید .
	
🛍 مبلغ پرداخت شده : $amount تومان
💰 موجودی جدید شما : $pluscoin تومان
💳 موجودی قبلی : {$userdata["amount"]} تومان",
	'reply_markup'=>$home
            ]);
$connect->query("UPDATE user SET `amount` = '$pluscoin' WHERE id = '$user' LIMIT 1");	
jijibot('sendmessage',[
	'chat_id'=>$admin[0],
	'text'=>"✅ #پرداخت موفق
	
💎 مبلغ خرید : $amount تومان
👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
if($userdata['inviter'] != '0'){
$userinviter = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '{$userdata['inviter']}' LIMIT 1"));
$porsant = ($amount * 10) / 100 ;
$coinplusinviter = $userinviter["amount"] + $porsant;
jijibot('sendmessage',[
	'chat_id'=>$userdata['inviter'],
	'text'=>"✅ تبریک ! زیر مجموعه شما از ربات خرید کرد و 10 درصد از موجودی خریداری شده به عنوان هدیه به شما تعلق گرفت
🗣 موجودی حساب شما با موفقیت افزایش  یافت , در صورت وجود هر گونه ایراد کافیست با پشتیبانی در تماس باشید .
	
🛍 موجودی خریداری شده : $amount تومان
💰 موجودی جدید شما : $coinplusinviter تومان
❄️ موجودی قبلی : {$userinviter["amount"]} تومان
🎁 مقدار هدیه : $porsant تومان
👤 خرید توسط : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
$connect->query("UPDATE user SET `amount` = '$coinplusinviter' WHERE id = '{$userdata['inviter']}' LIMIT 1");
}
?>
<html>
	<head>
		<title>ربات خرید شماره مجازی</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta name="description" content="ربات خرید شماره مجازی | صفحه افزایش موجودی ربات خرید شماره مجازی">
        <meta name="keywords" content="ربات خرید شماره مجازی">
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="assets/css/rtl.css" />
		<link rel="icon" type="image/png" href="images/fav.png">
	</head>
	<body>
		<!-- Wrapper -->
			<div id="wrapper">
				<!-- Header -->
					<header id="header" class="alt">
						<h1>ربات خرید شماره مجازی</h1>
						<p>صفحه افزایش موجودیِ حساب</p>
					</header>
				<!-- Main -->
					<div id="main">
					<!-- First Section -->
										<section id="intro" class="main">
								<div class="spotlight">
									<div class="content">
										<header class="major">
											<h2>پرداخت شما با موفقیت انجام شد و موجودی حساب شما با موفقیت افزایش یافت</h2>
										</header>
										<ul class="actions">
											<li><a href="<?php echo "https://t.me/$usernamebot";?>" class="button">برگشت به ربات</a></li>
										</ul>
									</div>
								</div>
							</section>
					</div>		
			</div>
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
	</body>
</html>
<?php 
} else {
	jijibot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"❌ پرداخت شما با موفقیت انجام نشد ! 
🔘 به منوی اصلی بازگشتید , میتوانید مجدد نسبت به افزایش موجودی حساب خود اقدام کنید .",
	'reply_markup'=>$home
            ]);
?>
<html>
	<head>
		<title>ربات خرید شماره مجازی</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta name="description" content="ربات خرید شماره مجازی | صفحه افزایش موجودی ربات خرید شماره مجازی">
        <meta name="keywords" content="ربات خرید شماره مجازی">
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="assets/css/rtl.css" />
		<link rel="icon" type="image/png" href="images/fav.png">
	</head>
	<body>
		<!-- Wrapper -->
			<div id="wrapper">
				<!-- Header -->
					<header id="header" class="alt">
						<h1>ربات خرید شماره مجازی</h1>
						<p>صفحه افزایش موجودیِ حساب</p>
					</header>
				<!-- Main -->
					<div id="main">
					<!-- First Section -->
										<section id="intro" class="main">
								<div class="spotlight">
									<div class="content">
										<header class="major">
											<h2>پرداخت شما با موفقیت انجام نشد ! به ربات برگشته و مجدد اقدام به خرید کنید</h2>
										</header>
										<ul class="actions">
											<li><a href="<?php echo "https://t.me/$usernamebot";?>" class="button">برگشت به ربات</a></li>
										</ul>
									</div>
								</div>
							</section>
					</div>		
			</div>
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
	</body>
</html>
<?php 
}
?>