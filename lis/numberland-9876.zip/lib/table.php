<?php
/* * * * * * * * * * * 
In The Name of God 
Source Of NumberLand
By PHP And Mysql
V.2
* * * * * * * * * *
Developer : filepick.ir
Telegram : @filepick
* * * * * * * * * * */
// یک بار صفحه اجرا شود
include '../config.php';
//========================== // table creator // ==============================
mysqli_multi_query($connect,"CREATE TABLE `user` (
    `id` int PRIMARY KEY,
	`step` varchar(20) DEFAULT NULL,
	`amount` int DEFAULT '0',
	`service` int DEFAULT '0',
	`member` int DEFAULT '0',
	`inviter` int DEFAULT '0'
    ); 	
	CREATE TABLE `number` (
    `id` bigint PRIMARY KEY,
	`from_id` int NOT NULL,
	`service` text NOT NULL,
	`country` text NOT NULL,
	`number` bigint NOT NULL,
	`time` varchar(30) DEFAULT '',
	`amount` int NOT NULL,
	`code` varchar(255) DEFAULT '0'
    );
    CREATE TABLE `stats` (
    `id` int NOT NULL,
	`service` int NOT NULL,
	`amount` int NOT NULL,
	`stats` TINYTEXT NOT NULL
    );
	CREATE TABLE `pay` (
    `id` varchar(255) NOT NULL PRIMARY KEY
    );
   CREATE TABLE `check` (
    `time` varchar(30) DEFAULT '',
	`check` varchar(30) DEFAULT ''
    ); 	
    CREATE TABLE `daily` (
    `time` varchar(30) DEFAULT '',
    `user` int DEFAULT '0'
    );
    CREATE TABLE `sendall` (
  	`step` varchar(20) DEFAULT NULL,
	`text` text DEFAULT NULL,
	`chat` varchar(100) DEFAULT NULL,
	`user` int DEFAULT '0'
    );
INSERT INTO `sendall` () VALUES (); INSERT INTO `daily` () VALUES (); INSERT INTO `check` () VALUES ();");
//========================== // Check connection // ==============================
$check = new mysqli('localhost' , $username, $password, $dbname);
if ($check->connect_error) {
   die("خطا در ارتصال به خاطره :" . $check->connect_error);
}
  echo "دیتابیس متصل و نصب شد ."
?>