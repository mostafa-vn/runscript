<?php
/* * * * * * * * * * * 
In The Name of God 
Source Of NumberLand
By PHP And Mysql
V.2
* * * * * * * * * *
Developer : filepick.ir
Telegram : @filepick
* * * * * * * * * * */
// کرون جاب هر دقیقه یک بار فعال شود
include '../bot.php'; // سازگار با سورس های خودم
//==============================// function //=======================================
function getstats($service , $country) {
global $apikey;
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, "https://api.numberland.ir/?apikey=$apikey&method=getinfo&country=$country&operator=any&service=$service");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT , 3);
$curl_exec = json_decode(curl_exec($ch));
foreach ($curl_exec as $k=>$v) {
if($v->count > 0) { $amount = (($v->amount * 30) / 100) +  $v->amount; return ['✅',$amount]; break; }
}
$amount = ($v->amount > 0)?(($v->amount * 30) / 100) +  $v->amount:'0';
return ['❌',$amount];	
}
//======================// send //=======================
$send = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `sendall` LIMIT 1"));
if($send["step"] == 'send'){
$alluser = mysqli_num_rows(mysqli_query($connect,"select id from user"));
$users = mysqli_query($connect,"SELECT id FROM `user` LIMIT 100 OFFSET {$send["user"]}");
if($send["chat"] == false){
while($row = mysqli_fetch_assoc($users))
     jijibot('sendmessage',[
          'chat_id'=>$row["id"],        
		  'text'=>$send["text"],
        ]);	
}else{
while($row = mysqli_fetch_assoc($users))
  jijibot('sendphoto',[
	'chat_id'=>$row["id"],
	'photo'=>$send["chat"],
	'caption'=>$send["text"],
 ]);
}
$connect->query("UPDATE `sendall` SET user = user + 100 LIMIT 1");
if($send["user"] + 100 >= $alluser){
  jijibot('sendmessage',[
      'chat_id'=>$admin[0],
      'text'=>"📍 پیام برای همه کابران ارسال شد",
 ]);
$connect->query("UPDATE `sendall` SET `step` = 'none' , `text` = '' , `user` = '0' , `chat` = '' LIMIT 1");	
}
}
//======================// forward //=======================
elseif($send["step"] == 'forward'){
$alluser = mysqli_num_rows(mysqli_query($connect,"select id from user"));
$users = mysqli_query($connect,"SELECT id FROM `user` LIMIT 100 OFFSET {$send["user"]}");
while($row = mysqli_fetch_assoc($users)){
jijibot('ForwardMessage',[
'chat_id'=>$row["id"],   
'from_chat_id'=>$send["chat"],
'message_id'=>$send["text"],
]);	
}
$connect->query("UPDATE `sendall` SET user = user + 100 LIMIT 1");
if($send["user"] + 100 >= $alluser){
  jijibot('sendmessage',[
      'chat_id'=>$admin[0],
      'text'=>"📍 پیام برای همه کابران فوروارد شد",
 ]);
$connect->query("UPDATE `sendall` SET `step` = 'none' , `text` = '' , `user` = '0' , `chat` = '' LIMIT 1");		
}
}
//======================// dailyuser //=======================
$daily = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `daily` WHERE time < '".date("Y-m-d H:i:s")."' LIMIT 1"));
if($daily == true){
$allchat = mysqli_num_rows(mysqli_query($connect,'select id from `user`'));
$chat = mysqli_query($connect,"SELECT * FROM `user` LIMIT 100 OFFSET {$daily["user"]}");
while($chinfo = mysqli_fetch_assoc($chat)){
jijibot('sendmessage',[
	'chat_id'=>$chinfo["id"], 
	'text'=>$start,
    		]);
}
$connect->query("UPDATE `daily` SET `user` = `user` + 100 LIMIT 1");
if($daily["user"] + 100 >= $allchat){
$time = date("Y-m-d H:i:s", strtotime("+5 day"));
$connect->query("UPDATE `daily` SET time = '$time' , `user` = '0' LIMIT 1");
}
}
//======================// numberstats //=======================
if(mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `check` WHERE time < '".date("Y-m-d H:i:s")."' LIMIT 1")) == true){
$time = date("Y-m-d H:i:s", strtotime("+30 minutes"));
$date = date("Y-m-d H:i:s");
$connect->query("UPDATE `check` SET time = '$time' , `check` = '$date' LIMIT 1");
if(mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `stats` LIMIT 1")) != true){
for($x = 0;$x <=  count($SERVICE_CODE) - 1;$x++){
for($z = 1;$z <=  count($countryarray);$z++)
$connect->query("INSERT INTO `stats` (id , service , stats , amount) VALUES ('$z' , '{$SERVICE_CODE[$x]}' , '".getstats($SERVICE_CODE[$x] , $z)[0]."' , '".getstats($SERVICE_CODE[$x] , $z)[1]."')");
}} else {
for($x = 0;$x <=  count($SERVICE_CODE) - 1;$x++){
for($z = 1;$z <=  count($countryarray);$z++)
$connect->query("UPDATE `stats` SET `stats` = '".getstats($SERVICE_CODE[$x] , $z)[0]."' , `amount` = '".getstats($SERVICE_CODE[$x] , $z)[1]."' WHERE `id` = '$z' AND `service` = '{$SERVICE_CODE[$x]}' LIMIT 1");
} } 
}
/* * * * * * * * * * * 
In The Name of God 
Source Of NumberLand
By PHP And Mysql
V.2
* * * * * * * * * *
Developer : filepick.ir
Telegram : @filepick
* * * * * * * * * * */
?>
