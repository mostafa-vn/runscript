<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
<style>
body {
    direction: rtl
}
</style>
<?php
if($_POST['fcprice'] and $_POST['fnprice'] and $_POST['recuring'] and $_POST['today'] and $_POST['mabna']){
$cp =  $_POST['fcprice'];
$np = $_POST['fnprice'];
$m = $_POST['mabna'];
$time2 = $_POST['recuring'];
$time1 = $_POST['today'];

function timeDiff($time2,$time1){
    $diff = strtotime($time2) - strtotime($time1);
    if($diff < 60){
        return $diff.' ثانیه قبل';
    }
    elseif($diff < 3600){
        return round($diff / 60,0,1).' دقیقه قبل';
    }
    elseif($diff >= 3660 && $diff < 86400){
        return round($diff / 3600,0,1).' ساعت قبل';
    }
    elseif($diff > 86400){
        return round($diff / 86400,0,1).' روز ';
    }
}
$c = $np-$cp;
echo '<div class="container-sm"><div class="alert alert-primary" role="alert">' . "ما به التفاوت بین دوبسته: " .  $c .  " تومان". '</div></div>';
echo "<br>";
$d = $c/$m;


$time3 = timeDiff($time2,$time1);
echo '<div class="container-sm"><div class="alert alert-danger" role="alert">' . "روزهای باقیمانده از بسته: " . $time3 . '</div></div>';

$result = round($time3*$d);

echo "<br>";
echo '<div class="container-sm"><div class="alert alert-success" role="alert">' . "مبلغ قابل پرداخت: " . $result . " تومان" . '</div></div>';
}
?>
<br><br><br>
<div class="container-sm">
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
        <label for="fname">تاریخ امروز</label><br>
        <input class="form-control" type="text" id="fname" name="today"><br>
        <label for="lname">تاریخ سررسید</label><br>
        <input class="form-control" type="text" id="lname" name="recuring"><br>
        <label for="fcprice">مبلغ بسته فعلی</label><br>
        <input class="form-control" type="text" id="fcprice" name="fcprice"><br>
        <label for="fnprice">مبلغ بسته جدید</label><br>
        <input class="form-control" type="text" id="fnprice" name="fnprice"><br><br>
        <label for="mabna">مبنا بر اساس دوره</label><br>
        <input class="form-control" type="text" id="mabna" name="mabna"><br><br>
        <input class="btn btn-primary" type="submit" value="محاسبه">
    </form>
</div>

